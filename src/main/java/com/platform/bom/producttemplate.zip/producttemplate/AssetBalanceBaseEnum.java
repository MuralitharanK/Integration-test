/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum AssetBalanceBaseEnum {
	/**
	 * Asset Balance base.
	 */
	SCHEDULED_BALANCE("1", "Scheduled Balance"),
	ACTUAL_BALANCE("2", "Actual Balance");

	private String id;
	private String name;

	AssetBalanceBaseEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
