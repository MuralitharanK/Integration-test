/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum InterestRateBasisEnum {
	/**
	 * Interest Rate Basis.
	 */
	D30_D360("1", "30/360"),
	D30_ACTUAL("2", "30/Actual"),
	ACTUAL_D360("3", "Actual/360"),
	ACTUAL_D365("4", "Actual/365"),
	ACTUAL_ACTUAL("5", "Actual/Actual");

	private String id;
	private String name;

	InterestRateBasisEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
