/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public class LiabilityProductDefinition extends BaseProductDefinition {
	
	private static final long serialVersionUID = -4912741235047496184L;

	private Double minimumBalance;

	/**
	 *  Credit - Interest Rate and Definition section.
	 */
	private InterestRateAndDefinition creditInterestRateDef;

	/**
	 * Enum: LiabilityBalanceBaseEnum
	 * Options:
	 * 2) Lowest eod balance during the period-
	 *  a) Freq:
	 *  b) From date and to date of month
	 * 3) Daily closing balance
	 */
	private short balanceBase;

	private Boolean accountAliasAllowed;
}
