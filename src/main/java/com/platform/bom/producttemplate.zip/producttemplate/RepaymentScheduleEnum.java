/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum RepaymentScheduleEnum {
	/**
	 * Repayment Schedules.
	 */
	EMI("1", "EMI"),
	VARIABLE("2", "Fixed principal with accrued interest"),
	STRUCTURED("3", "Structured"),
	BULLET("4", "Bullet");

	private String id;
	private String name;

	RepaymentScheduleEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
