/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum LiabilityBalanceBaseEnum {
	/**
	 * Allowed repayment modes.
	 */
	FREQ("1", "Lowest EOD balance during the period - Freq"),
	DATEOFMONTH("2", "Lowest EOD balance during the period - From date and to date of month"),
	DAILY("3", "Daily closing balance");

	private String id;
	private String name;

	LiabilityBalanceBaseEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
