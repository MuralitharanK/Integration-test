/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum ProductClassEnum {

	/**
	 * product types.
	 */
	SB("1", "SB"), CA("2", "CA"), TD("3", "TD"), RD("4", "RD"), LOAN("5", "LOAN");

	private String id;
	private String name;

	ProductClassEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
