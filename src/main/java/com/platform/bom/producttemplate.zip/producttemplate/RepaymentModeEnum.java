/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum RepaymentModeEnum {
	/**
	 * Allowed repayment modes.
	 */
	EMI("1", "Account Auto Debit"),
	AUTODEBIT("2", "Auto debit/SI from external account"),
	CHEQUE("3", "Cheque"),
	CASH("4", "Cash");

	private String id;
	private String name;

	RepaymentModeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
