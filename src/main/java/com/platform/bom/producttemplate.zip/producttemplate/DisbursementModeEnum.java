/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum DisbursementModeEnum {
	/**
	 * Disbursement modes.
	 */
	ACCOUNT_CREDIT("1", "Account Credit"),
	CHEQUE_DRAFT("2", "Cheque/Draft"),
	EXTERNAL("3", "External Account transfer");

	private String id;
	private String name;

	DisbursementModeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
