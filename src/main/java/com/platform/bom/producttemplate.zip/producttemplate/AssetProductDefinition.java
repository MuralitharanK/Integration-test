/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

import javax.validation.constraints.NotNull;

/**
 * @author - Muralitharan K
 *
 */
public class AssetProductDefinition extends BaseProductDefinition {

	private static final long serialVersionUID = -3071806168364297660L;
	/**
	 * Control Parameters: Asset
	 */
	@NotNull
	private Double minimumLoanAmount;
	@NotNull
	private Double maximumLoanAmount;

	@NotNull
	private Integer minimumLoanTerm;
	
	@NotNull
	private Integer maximumLoanTerm;
	
	private Integer lockInPeriod;
	
	private Boolean backdatedTransactionAllowed;
	
	private Integer backdatedTransactionAllowedDays;
	
	private Boolean revolving;
	
	/**
	 * Enum : AssetBalanceBaseEnum
	 * Balance base part of InterestRateAnd Definition.
	 * -Scheduled balance
	 * -Actual balance
	 */
	private short balanceBase;
	//Penalty interest configuration: LINK
	
	/**
	 * Disbursement section.
	 */
	/**
	 * Enum :DisbursementModeEnum
	 * Values:
	 *� Account Credit
	 *  Cheque/Draft
	 *  External Account transfer
	 */
	private short disbursementMode;
	
	private Boolean subsequentDiscursement;
	
	/**
	 * Repayment section.
	 * 
	 * Loan account arrears components are 
	 * 1. Principal Arrears
	 * 2. Interest Arrears 
	 * 3. Fee Arrears
	 * 4. Penalty Fee Arrears
	 * 5. Penalty Interest Arrears
	 */
	@NotNull
	private String appropriationSequence;
	
	/**
	 * Enum : AppropriationTypeEnum
	 * Options:
	 * 1) Horizontal
	 * 2) vertical
	 */
	private short appropriationType;
	
	private Boolean partialPayoffAllowed;
	
	private Boolean advancePaymentAllowed;
	
	@NotNull
	private Integer repaymentGraceDays;
	
	@NotNull
	private Double penaltyAmount;

	/**
	 * Enum : RepaymentScheduleEnum
	 * The dropdown values are
	 * 1. EMI
	 * 2. Fixed principal with accrued interest
	 * 3. Structured
	 * 4. Bullet
	 */
	@NotNull
	private short repaymentSchedule;

	/**
	 * Enum: RepaymentModeEnum
	 * Allowed repayment modes are
	 * 1. Account auto Debit
	 * 2. Auto debit/SI from external account
	 * 3. Cheque
	 * 4. Cash
	 */
	@NotNull
	private short modeOfRepayment;
	
}
