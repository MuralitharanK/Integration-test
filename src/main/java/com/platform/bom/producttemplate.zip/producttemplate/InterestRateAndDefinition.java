/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

import java.io.Serializable;
import java.util.List;

/**
 * @author - Muralitharan K
 *
 */
public class InterestRateAndDefinition implements Serializable {

	private static final long serialVersionUID = 7089708288709268638L;
	/**
	 * if yes� then accrual basis else cash basis
	 */
	private Boolean interestAccuralRequired;
	/**
	 * Class AccrualFrequencyEnum:
	 * The dropdown values are
	 *�� Daily
	 *���Monthly
	 *���Quarterly
	 *���Half yearly
	 *���Yearly
	 */
	private short accrualFrequency;
	/**
	 * Class : InterestRateBasisEnum
	 * Options:
	 * 30/360
	 * 30/Actual
	 * Actual/360
	 * Actula/365
	 * Actual/Actual
	 */
	private short interestRateBasis;
	/**
	 * GL Code which intern has configuration for interest related accounts�
	 */
	private List<String> interestPointer;
	
	/**
	 * Enum : AllowedRateTypeEnum
	 * The dropdown contains 
	 *� Fixed
	 *� Variable
	 *� Both
	 */
	private String allowedRateType;
	
	private float fixedInterestRate;
	
	private float variableInterestRate;
	
	private float marginOrSpread;
	private Boolean rateRevisionAllowed;
	
	private String rateRevisionOrResetFrequency;
	
	private float interestApplicationDay;
	
	private float interestApplicationEOM;
	
	private float interestRate;
	
	private float interestRateDay;
	
	private float interestCap;
	
	private float interestCollar;
	
	private Double taxOnInterest;
}
