/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum AllowedRateTypeEnum {

	/**
	 * Allowed Rate Types.
	 */
	FIXED("1", "Fixed"),
	VARIABLE("2", "Variable"),
	BOTH("3", "Both");

	private String id;
	private String name;

	AllowedRateTypeEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
