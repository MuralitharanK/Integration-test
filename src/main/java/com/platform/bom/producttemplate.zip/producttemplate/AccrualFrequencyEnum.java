/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

/**
 * @author - Muralitharan K
 *
 */
public enum AccrualFrequencyEnum {
	/**
	 * Accrual frequency types.
	 */
	DAILY("1", "Daily"), 
	MONTHLY("2", "Monthly"), 
	QUARTERLY("3", "Quarterly"), 
	HALFYEARLY("4", "Half Yearly"), 
	YEARLY("5", "Yearly");

	private String id;
	private String name;

	AccrualFrequencyEnum(String id, String name) {
		this.id = id;
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
