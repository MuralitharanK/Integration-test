/**
 * Copyright (C) Altimetrik 2016. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Altimetrik. You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and conditions
 * entered into with Altimetrik.
 */

package com.platform.bom.producttemplate;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.platform.bom.domain.BaseEntity;
import com.platform.bom.domain.annotation.TenantAware;

/**
 * @author - Muralitharan K
 *
 */
@TenantAware
public class BaseProductDefinition extends BaseEntity {

	private static final long serialVersionUID = 2925431578195499802L;

	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]*")
	private String productCode;
	
	@NotNull
	private String productName;
	
	/**
	 * Product Class:ProductClassEnum
	 * 1. SB
	 * 2. CA
	 * 3. TD
	 * 4. RD
	 * 5. LOAN
	 */
	@NotNull
	private short productClass;
	
	@NotNull
	private Date productStartDate;
	
	private Date productExpiryDate;
	private String defaultCurrency;
	private Boolean debitInterestAllowed;
	/**
	 *  Debit - Interest Rate and Definition section.
	 */
	private InterestRateAndDefinition debitInterestRateDef;
	
	/**
	 * Accounting - section.
	 */
	
	private List<String> assetGLCodes;
	
	private List<String> liabilityGLCodes;
	private List<String> incomeGLCodes;
	private List<String> expenseGLCodes;
	private Boolean blockingAllowed;
	
}
